var backImage = loadImage("game.jpg");

var x= width/2; //BallX
var y= height/2; //BallY
var w=50;
var h=50;
var speedX=3; //RichtungX
var speedY=3; //RichtungY
var score=0; //Punktezahl
 
//Ende des Spiels
var gameEnde=function(){      
   fill(random(0,255), random(0,255),random(0,255));
  textSize(58);
  text("GAMEOVER",69,249);
  fill(43, 40, 40);
  textSize(36);
  text("Punktezahl: " ,140, 300);
  fill(156, 15, 83);
  textSize(41);
  text(score, 325, 300);
};
 
//Punkteanzahl
var points=function(x,y){
  fill(0, 0, 0);
  textSize(18);
  text("Points:", 10,25);
  text(score, 70, 25);
};
 
rectMode(CENTER);


 
//DRAW
draw = function(){

image(backImage,-86,-30);
  
     
  //Zwischenlinie
  noStroke();
  fill(178, 212, 192);
  rect(238,272,5,536);
 
  //Ball springt
  fill(247, 115, 8);
  ellipse(x,y,30,30);
 
  //RotesPaddle
  if(x<28 && x>25){
      if(y<(pmouseY+60) && y>(pmouseY-60)){
         speedX=-speedX; //RichtungsÃƒÂ¤nderung
         score++; //ErhÃƒÂ¶hung
      }    
  }
  //LilaPaddle
  if(x<458 && x>455){
      if(y<(pmouseY+60) && y>(pmouseY-60)){
         speedX=-speedX; //RichtungsÃƒÂ¤nderung
         score++; //ErhÃƒÂ¶hung
      }    
  }
  //KeinPaddle/GAMEOVER
  if (x>485 || x<10){
      gameEnde(); //Beenden
  }
  //UntereSeite
  if(y>525){
      speedY=-speedY; //RichtungsÃƒÂ¤nderung
  }
  //ObereSeite
  else if(y<8){
      speedY=-speedY; //RichtungsÃƒÂ¤nderung
  }
 
  //Bewegung des Balls
  x=x+speedX;
  y=y+speedY;
 
  //blauesPaddle
  fill(255, 255, 255);
  rect(10,pmouseY,17,114);
  //LilaPaddle
  fill(255, 255, 255);
  rect(487,pmouseY,17,114);
 
  points(x, y);//ScoreUpdaten
};
    